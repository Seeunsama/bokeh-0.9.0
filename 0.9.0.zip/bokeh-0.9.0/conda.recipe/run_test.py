import bokeh
print('bokeh.__version__: %s' % bokeh.__version__)
