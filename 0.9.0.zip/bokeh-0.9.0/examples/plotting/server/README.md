
The examples in this directory illustrate the use of the Bokeh server for
storing persistent state between a browser interactive plot, and a python
script driving the plot. To run these examples you must execute the command
'python bokeh-server' in the top-level Bokeh source directory first. Then
you can run any of the examples here by running them as python scripts,
e.g. 'python vector.py'.
