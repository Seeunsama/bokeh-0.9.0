
The examples in this directory illustrate the use of Bokeh inside the IPython
noteboook. To view the examples here, first execute 'ipython notebook' in this 
directory. A web browser should automatically open up to the IPython Dashboard
at localhost:8891 (or you may navigate there manually). Click on any of the 
notebooks listed to open and explore.


