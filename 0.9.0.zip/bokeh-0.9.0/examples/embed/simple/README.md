
# Polynomial Graph Example

This demonstrates the ability of bokeh to easily embed into a webpage.

This example uses the excellent python library Flask to handle creating the web page and
handling the data to populate the graph.

With this example, you should be able to embed bokeh into pretty much any webpage!
