Please consult http://bokeh.pydata.org/docs/contributing.html for more 
information about contributing to BokehJS. 
